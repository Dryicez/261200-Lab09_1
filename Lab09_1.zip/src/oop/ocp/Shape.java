package oop.ocp;

public abstract class Shape {
    public abstract double calculateArea();
}

